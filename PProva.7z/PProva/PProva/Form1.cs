﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PProva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            int N = 0;

            var auxiliar2 = Interaction.InputBox("Quantidade de Jogadores:", "Numero de Pontos");
            int.TryParse(auxiliar2, out N);

            
            int[,] matrizPontuacao = new int[N, 3];

            

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < matrizPontuacao.Length; j++)
                {
                    if (j == 0)
                    {
                        var auxiliar = Interaction.InputBox("Pontos Nível facil: ", "Entrada de pontos faceis");
                        if (!int.TryParse(auxiliar, out matrizPontuacao[i, 0]))
                        {
                            MessageBox.Show("Erro, informar pontuação em int");
                           
                            continue;
                        }
                    }
                    else
                        if (j == 1)

                    {
                        var auxiliar = Interaction.InputBox("Pontos Nível Medio: ", "Entrada de pontos medios");
                        if (!int.TryParse(auxiliar, out matrizPontuacao[i, 1]))
                        {
                            MessageBox.Show("Erro, informar pontuação em int");
                            
                            continue;
                        }
                    }

                    else
                        if (j == 2)


                    {
                        var auxiliar = Interaction.InputBox("Pontos Nível Dificil: ", "Entrada de pontos Dificeis");
                        if (!int.TryParse(auxiliar, out matrizPontuacao[i,2]))
                        {
                            MessageBox.Show("Erro, informar pontuação em int");
                            
                            continue;
                        }
                    }
                    
                }
                int mediaPontuacao = (matrizPontuacao[i, 0] + matrizPontuacao[i, 1] + matrizPontuacao[i, 2]) / 3;
                lstBxPlacar.Items.Add("Jogador: ", (i + 1) + "Pontos Nivel Facil"[i, 0] + "Pontos Nivel Medio"[i, 1] + "Pontos Nivel Dificil"[i, 2] + "Media Pontuacao: " + mediaPontuacao);
            }

            
        }
    }
}